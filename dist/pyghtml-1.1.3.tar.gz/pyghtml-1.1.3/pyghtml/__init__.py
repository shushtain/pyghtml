"""Library for building static HTML pages"""

from .tags import *
